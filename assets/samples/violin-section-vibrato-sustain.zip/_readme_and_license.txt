Pack downloaded from Freesound
----------------------------------------

"VSCO 2 CE  - Strings - Violin Section - vibrato sustain"

This Pack of sounds contains sounds by the following user:
 - sgossner ( https://freesound.org/people/sgossner/ )

You can find this pack online at: https://freesound.org/people/sgossner/packs/21062/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 374598__sgossner__violin-section-vibrato-sustain-f5-vlnens_susvib_g4_v2.wav.wav
    * url: https://freesound.org/s/374598/
    * license: Creative Commons 0
  * 374597__sgossner__violin-section-vibrato-sustain-f3-vlnens_susvib_g2_v2.wav.wav
    * url: https://freesound.org/s/374597/
    * license: Creative Commons 0
  * 374596__sgossner__violin-section-vibrato-sustain-f4-vlnens_susvib_f3_v2.wav.wav
    * url: https://freesound.org/s/374596/
    * license: Creative Commons 0
  * 374595__sgossner__violin-section-vibrato-sustain-e5-vlnens_susvib_e4_v2.wav.wav
    * url: https://freesound.org/s/374595/
    * license: Creative Commons 0
  * 374594__sgossner__violin-section-vibrato-sustain-d6-vlnens_susvib_d5_v2.wav.wav
    * url: https://freesound.org/s/374594/
    * license: Creative Commons 0
  * 374593__sgossner__violin-section-vibrato-sustain-d4-vlnens_susvib_d3_v2.wav.wav
    * url: https://freesound.org/s/374593/
    * license: Creative Commons 0
  * 374592__sgossner__violin-section-vibrato-sustain-c5-vlnens_susvib_c4_v2.wav.wav
    * url: https://freesound.org/s/374592/
    * license: Creative Commons 0
  * 374591__sgossner__violin-section-vibrato-sustain-b5-vlnens_susvib_b4_v2.wav.wav
    * url: https://freesound.org/s/374591/
    * license: Creative Commons 0
  * 374590__sgossner__violin-section-vibrato-sustain-b3-vlnens_susvib_b2_v2.wav.wav
    * url: https://freesound.org/s/374590/
    * license: Creative Commons 0
  * 374589__sgossner__violin-section-vibrato-sustain-a4-vlnens_susvib_a3_v2.wav.wav
    * url: https://freesound.org/s/374589/
    * license: Creative Commons 0
  * 374588__sgossner__violin-section-vibrato-sustain-a3-vlnens_susvib_a2_v2.wav.wav
    * url: https://freesound.org/s/374588/
    * license: Creative Commons 0
  * 374587__sgossner__violin-section-vibrato-sustain-f5-vlnens_susvib_g4_v1.wav.wav
    * url: https://freesound.org/s/374587/
    * license: Creative Commons 0
  * 374586__sgossner__violin-section-vibrato-sustain-f3-vlnens_susvib_g2_v1.wav.wav
    * url: https://freesound.org/s/374586/
    * license: Creative Commons 0
  * 374585__sgossner__violin-section-vibrato-sustain-f4-vlnens_susvib_f3_v1.wav.wav
    * url: https://freesound.org/s/374585/
    * license: Creative Commons 0
  * 374584__sgossner__violin-section-vibrato-sustain-e5-vlnens_susvib_e4_v1.wav.wav
    * url: https://freesound.org/s/374584/
    * license: Creative Commons 0
  * 374583__sgossner__violin-section-vibrato-sustain-d6-vlnens_susvib_d5_v1.wav.wav
    * url: https://freesound.org/s/374583/
    * license: Creative Commons 0
  * 374582__sgossner__violin-section-vibrato-sustain-d4-vlnens_susvib_d3_v1.wav.wav
    * url: https://freesound.org/s/374582/
    * license: Creative Commons 0
  * 374581__sgossner__violin-section-vibrato-sustain-c5-vlnens_susvib_c4_v1.wav.wav
    * url: https://freesound.org/s/374581/
    * license: Creative Commons 0
  * 374580__sgossner__violin-section-vibrato-sustain-b5-vlnens_susvib_b4_v1.wav.wav
    * url: https://freesound.org/s/374580/
    * license: Creative Commons 0
  * 374579__sgossner__violin-section-vibrato-sustain-b3-vlnens_susvib_b2_v1.wav.wav
    * url: https://freesound.org/s/374579/
    * license: Creative Commons 0
  * 374578__sgossner__violin-section-vibrato-sustain-a4-vlnens_susvib_a3_v1.wav.wav
    * url: https://freesound.org/s/374578/
    * license: Creative Commons 0
  * 374577__sgossner__violin-section-vibrato-sustain-a3-vlnens_susvib_a2_v1.wav.wav
    * url: https://freesound.org/s/374577/
    * license: Creative Commons 0


