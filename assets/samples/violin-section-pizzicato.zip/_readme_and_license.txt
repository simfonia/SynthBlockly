Pack downloaded from Freesound
----------------------------------------

"VSCO 2 CE  - Strings - Violin Section - pizzicato"

This Pack of sounds contains sounds by the following user:
 - sgossner ( https://freesound.org/people/sgossner/ )

You can find this pack online at: https://freesound.org/people/sgossner/packs/21060/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 374532__sgossner__violin-section-pizzicato-f5-vlnens_pizz_g4_v2_rr2.wav.wav
    * url: https://freesound.org/s/374532/
    * license: Creative Commons 0
  * 374531__sgossner__violin-section-pizzicato-f3-vlnens_pizz_g2_v2_rr2.wav.wav
    * url: https://freesound.org/s/374531/
    * license: Creative Commons 0
  * 374530__sgossner__violin-section-pizzicato-f4-vlnens_pizz_f3_v2_rr2.wav.wav
    * url: https://freesound.org/s/374530/
    * license: Creative Commons 0
  * 374529__sgossner__violin-section-pizzicato-e5-vlnens_pizz_e4_v2_rr2.wav.wav
    * url: https://freesound.org/s/374529/
    * license: Creative Commons 0
  * 374528__sgossner__violin-section-pizzicato-d6-vlnens_pizz_d5_v2_rr2.wav.wav
    * url: https://freesound.org/s/374528/
    * license: Creative Commons 0
  * 374527__sgossner__violin-section-pizzicato-d4-vlnens_pizz_d3_v2_rr2.wav.wav
    * url: https://freesound.org/s/374527/
    * license: Creative Commons 0
  * 374526__sgossner__violin-section-pizzicato-c5-vlnens_pizz_c4_v2_rr2.wav.wav
    * url: https://freesound.org/s/374526/
    * license: Creative Commons 0
  * 374525__sgossner__violin-section-pizzicato-b5-vlnens_pizz_b4_v2_rr2.wav.wav
    * url: https://freesound.org/s/374525/
    * license: Creative Commons 0
  * 374524__sgossner__violin-section-pizzicato-b3-vlnens_pizz_b2_v2_rr2.wav.wav
    * url: https://freesound.org/s/374524/
    * license: Creative Commons 0
  * 374523__sgossner__violin-section-pizzicato-a4-vlnens_pizz_a3_v2_rr2.wav.wav
    * url: https://freesound.org/s/374523/
    * license: Creative Commons 0
  * 374522__sgossner__violin-section-pizzicato-a3-vlnens_pizz_a2_v2_rr2.wav.wav
    * url: https://freesound.org/s/374522/
    * license: Creative Commons 0
  * 374521__sgossner__violin-section-pizzicato-f5-vlnens_pizz_g4_v1_rr2.wav.wav
    * url: https://freesound.org/s/374521/
    * license: Creative Commons 0
  * 374520__sgossner__violin-section-pizzicato-f3-vlnens_pizz_g2_v1_rr2.wav.wav
    * url: https://freesound.org/s/374520/
    * license: Creative Commons 0
  * 374519__sgossner__violin-section-pizzicato-f4-vlnens_pizz_f3_v1_rr2.wav.wav
    * url: https://freesound.org/s/374519/
    * license: Creative Commons 0
  * 374518__sgossner__violin-section-pizzicato-e5-vlnens_pizz_e4_v1_rr2.wav.wav
    * url: https://freesound.org/s/374518/
    * license: Creative Commons 0
  * 374517__sgossner__violin-section-pizzicato-d6-vlnens_pizz_d5_v1_rr2.wav.wav
    * url: https://freesound.org/s/374517/
    * license: Creative Commons 0
  * 374516__sgossner__violin-section-pizzicato-d4-vlnens_pizz_d3_v1_rr2.wav.wav
    * url: https://freesound.org/s/374516/
    * license: Creative Commons 0
  * 374515__sgossner__violin-section-pizzicato-c5-vlnens_pizz_c4_v1_rr2.wav.wav
    * url: https://freesound.org/s/374515/
    * license: Creative Commons 0
  * 374514__sgossner__violin-section-pizzicato-b5-vlnens_pizz_b4_v1_rr2.wav.wav
    * url: https://freesound.org/s/374514/
    * license: Creative Commons 0
  * 374513__sgossner__violin-section-pizzicato-b3-vlnens_pizz_b2_v1_rr2.wav.wav
    * url: https://freesound.org/s/374513/
    * license: Creative Commons 0
  * 374512__sgossner__violin-section-pizzicato-a4-vlnens_pizz_a3_v1_rr2.wav.wav
    * url: https://freesound.org/s/374512/
    * license: Creative Commons 0
  * 374511__sgossner__violin-section-pizzicato-a3-vlnens_pizz_a2_v1_rr2.wav.wav
    * url: https://freesound.org/s/374511/
    * license: Creative Commons 0
  * 374510__sgossner__violin-section-pizzicato-f5-vlnens_pizz_g4_v2_rr1.wav.wav
    * url: https://freesound.org/s/374510/
    * license: Creative Commons 0
  * 374509__sgossner__violin-section-pizzicato-f3-vlnens_pizz_g2_v2_rr1.wav.wav
    * url: https://freesound.org/s/374509/
    * license: Creative Commons 0
  * 374508__sgossner__violin-section-pizzicato-f4-vlnens_pizz_f3_v2_rr1.wav.wav
    * url: https://freesound.org/s/374508/
    * license: Creative Commons 0
  * 374507__sgossner__violin-section-pizzicato-e5-vlnens_pizz_e4_v2_rr1.wav.wav
    * url: https://freesound.org/s/374507/
    * license: Creative Commons 0
  * 374506__sgossner__violin-section-pizzicato-d6-vlnens_pizz_d5_v2_rr1.wav.wav
    * url: https://freesound.org/s/374506/
    * license: Creative Commons 0
  * 374505__sgossner__violin-section-pizzicato-d4-vlnens_pizz_d3_v2_rr1.wav.wav
    * url: https://freesound.org/s/374505/
    * license: Creative Commons 0
  * 374504__sgossner__violin-section-pizzicato-c5-vlnens_pizz_c4_v2_rr1.wav.wav
    * url: https://freesound.org/s/374504/
    * license: Creative Commons 0
  * 374503__sgossner__violin-section-pizzicato-b5-vlnens_pizz_b4_v2_rr1.wav.wav
    * url: https://freesound.org/s/374503/
    * license: Creative Commons 0
  * 374502__sgossner__violin-section-pizzicato-b3-vlnens_pizz_b2_v2_rr1.wav.wav
    * url: https://freesound.org/s/374502/
    * license: Creative Commons 0
  * 374501__sgossner__violin-section-pizzicato-a4-vlnens_pizz_a3_v2_rr1.wav.wav
    * url: https://freesound.org/s/374501/
    * license: Creative Commons 0
  * 374500__sgossner__violin-section-pizzicato-a3-vlnens_pizz_a2_v2_rr1.wav.wav
    * url: https://freesound.org/s/374500/
    * license: Creative Commons 0
  * 374499__sgossner__violin-section-pizzicato-f5-vlnens_pizz_g4_v1_rr1.wav.wav
    * url: https://freesound.org/s/374499/
    * license: Creative Commons 0
  * 374498__sgossner__violin-section-pizzicato-f3-vlnens_pizz_g2_v1_rr1.wav.wav
    * url: https://freesound.org/s/374498/
    * license: Creative Commons 0
  * 374497__sgossner__violin-section-pizzicato-f4-vlnens_pizz_f3_v1_rr1.wav.wav
    * url: https://freesound.org/s/374497/
    * license: Creative Commons 0
  * 374496__sgossner__violin-section-pizzicato-e5-vlnens_pizz_e4_v1_rr1.wav.wav
    * url: https://freesound.org/s/374496/
    * license: Creative Commons 0
  * 374495__sgossner__violin-section-pizzicato-d6-vlnens_pizz_d5_v1_rr1.wav.wav
    * url: https://freesound.org/s/374495/
    * license: Creative Commons 0
  * 374494__sgossner__violin-section-pizzicato-d4-vlnens_pizz_d3_v1_rr1.wav.wav
    * url: https://freesound.org/s/374494/
    * license: Creative Commons 0
  * 374493__sgossner__violin-section-pizzicato-c5-vlnens_pizz_c4_v1_rr1.wav.wav
    * url: https://freesound.org/s/374493/
    * license: Creative Commons 0
  * 374492__sgossner__violin-section-pizzicato-b5-vlnens_pizz_b4_v1_rr1.wav.wav
    * url: https://freesound.org/s/374492/
    * license: Creative Commons 0
  * 374491__sgossner__violin-section-pizzicato-b3-vlnens_pizz_b2_v1_rr1.wav.wav
    * url: https://freesound.org/s/374491/
    * license: Creative Commons 0
  * 374490__sgossner__violin-section-pizzicato-a4-vlnens_pizz_a3_v1_rr1.wav.wav
    * url: https://freesound.org/s/374490/
    * license: Creative Commons 0
  * 374489__sgossner__violin-section-pizzicato-a3-vlnens_pizz_a2_v1_rr1.wav.wav
    * url: https://freesound.org/s/374489/
    * license: Creative Commons 0


